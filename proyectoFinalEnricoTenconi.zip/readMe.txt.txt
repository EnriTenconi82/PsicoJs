Buenas,
envio repo ,gitpages y detalles de proyecto

-gitpages
https://enritenconi82.github.io/PsicoJs/

-repo github

https://github.com/EnriTenconi82/PsicoJs


-contacto.html
	desde la pagina se envian mensajes al sessionStorage;
	desde el footer de la pagina se accede a la area privada 
	(user:nemuadmin
	contraseña:nemuuser)	

	-desde la X se desloguea desde el admin
	-por inactividad de 60 segundo se desloguea la pagina

	-desde la botonera de la zona privada se puede
	-buscar mensajes por 
 		 apellido
	 	 apellido y nombre
		 mensaje nuevos o viejos
	-eliminar mensajes viejos

	-desde el carousel de mensajes se puede
	 -pasar a leido el mensaje visualizado
	 -borrar mensaje visualizado

	